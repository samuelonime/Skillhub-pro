const router = require('express').Router();
const db = require('../config/database');
const { authenticate } = require('../middleware/auth');
const { success, badRequest } = require('../utils/response');

const REWARDS_CATALOG = [
  { id: 'r-001', name: 'Premium Course Voucher', description: 'Access any premium course for 30 days', cost: 500, category: 'learning', icon: 'graduation-cap' },
  { id: 'r-002', name: 'Featured Profile Badge', description: 'Get featured in employer searches for 7 days', cost: 300, category: 'visibility', icon: 'star' },
  { id: 'r-003', name: 'Resume Review', description: 'Professional resume review by an expert', cost: 750, category: 'career', icon: 'file-alt' },
  { id: 'r-004', name: 'Mock Interview Session', description: '1-hour mock interview with feedback', cost: 1000, category: 'career', icon: 'comments' },
  { id: 'r-005', name: 'SkillHub T-Shirt', description: 'Official SkillHub merchandise', cost: 200, category: 'merchandise', icon: 'tshirt' },
  { id: 'r-006', name: 'Lifetime Certificate Badge', description: 'Permanent gold badge on your profile', cost: 2000, category: 'prestige', icon: 'award' },
];

// GET merit coins balance
router.get('/merit-coins', authenticate, (req, res) => {
  return success(res, {
    balance: req.user.meritCoins || 0,
    history: db.transactions.filter(t => t.userId === req.user.id),
  });
});

// GET rewards catalog
router.get('/', authenticate, (req, res) => {
  return success(res, { catalog: REWARDS_CATALOG, balance: req.user.meritCoins || 0 });
});

// GET transactions
router.get('/transactions', authenticate, (req, res) => {
  return success(res, db.transactions.filter(t => t.userId === req.user.id));
});

// POST redeem reward
router.post('/:id/redeem', authenticate, (req, res) => {
  const reward = REWARDS_CATALOG.find(r => r.id === req.params.id);
  if (!reward) return badRequest(res, 'Reward not found');

  const balance = req.user.meritCoins || 0;
  if (balance < reward.cost) return badRequest(res, `Insufficient Merit Coins. Need ${reward.cost - balance} more.`);

  const newBalance = balance - reward.cost;
  db.updateUser(req.user.id, { meritCoins: newBalance });

  const transaction = {
    id: `tx-${Date.now()}`,
    userId: req.user.id,
    type: 'redeem',
    amount: -reward.cost,
    description: `Redeemed: ${reward.name}`,
    balanceAfter: newBalance,
    createdAt: new Date(),
  };
  db.transactions.push(transaction);
  db.addNotification(req.user.id, { type: 'success', icon: 'gift', title: 'Reward Redeemed!', message: `You redeemed ${reward.name} for ${reward.cost} coins` });

  return success(res, { reward, newBalance, transaction }, `${reward.name} redeemed successfully!`);
});

module.exports = router;
