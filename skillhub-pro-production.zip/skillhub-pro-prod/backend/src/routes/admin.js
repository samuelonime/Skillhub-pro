const router = require('express').Router();
const db = require('../config/database');
const { authenticate, requireRole } = require('../middleware/auth');
const { success, notFound } = require('../utils/response');

// All admin routes require admin role
router.use(authenticate, requireRole('admin'));

// GET platform stats
router.get('/stats', (req, res) => {
  const now = new Date();
  const lastMonth = new Date(now.getFullYear(), now.getMonth() - 1, 1);

  return success(res, {
    users: {
      total: db.users.length,
      students: db.users.filter(u => u.role === 'student').length,
      employers: db.users.filter(u => u.role === 'employer').length,
      instructors: db.users.filter(u => u.role === 'instructor').length,
      newThisMonth: db.users.filter(u => u.createdAt > lastMonth).length,
    },
    courses: { total: db.courses.length, totalEnrollments: db.courses.reduce((s, c) => s + c.enrolledBy.length, 0) },
    jobs: { total: db.jobs.length, active: db.jobs.filter(j => j.status === 'active').length, totalApplications: db.applications.length },
    certificates: { total: db.certificates.length, verified: db.certificates.filter(c => c.status === 'verified').length, pending: db.certificates.filter(c => c.status === 'pending').length },
    revenue: { meritCoinsIssued: db.users.reduce((s, u) => s + (u.meritCoins || 0), 0) },
  });
});

// GET all users
router.get('/users', (req, res) => {
  const { role, search } = req.query;
  let users = db.users.map(({ password, ...u }) => u);
  if (role) users = users.filter(u => u.role === role);
  if (search) users = users.filter(u => `${u.firstName} ${u.lastName} ${u.email}`.toLowerCase().includes(search.toLowerCase()));
  return success(res, { users, total: users.length });
});

// GET user by ID
router.get('/users/:id', (req, res) => {
  const user = db.findUserById(req.params.id);
  if (!user) return notFound(res, 'User not found');
  const { password, ...safe } = user;
  return success(res, safe);
});

// PUT update user (admin) — only allow a safe allow-list of fields
router.put('/users/:id', (req, res) => {
  const ALLOWED_UPDATE_FIELDS = ['role', 'verified', 'meritCoins', 'title'];
  const updates = {};
  ALLOWED_UPDATE_FIELDS.forEach(k => {
    if (req.body[k] !== undefined) updates[k] = req.body[k];
  });
  // Validate role if provided
  const VALID_ROLES = ['student', 'employer', 'instructor', 'admin'];
  if (updates.role && !VALID_ROLES.includes(updates.role)) {
    return notFound(res, 'Invalid role value');
  }
  if (Object.keys(updates).length === 0) {
    return notFound(res, 'No updatable fields provided');
  }
  const updated = db.updateUser(req.params.id, updates);
  if (!updated) return notFound(res, 'User not found');
  const { password, ...safe } = updated;
  return success(res, safe, 'User updated');
});

// DELETE user
router.delete('/users/:id', (req, res) => {
  const idx = db.users.findIndex(u => u.id === req.params.id);
  if (idx === -1) return notFound(res, 'User not found');
  if (req.params.id === req.user.id) return success(res, null, 'Cannot delete your own account');
  db.users.splice(idx, 1);
  return success(res, null, 'User deleted');
});

// GET all certificates (admin view)
router.get('/certificates', (req, res) => {
  const certs = db.certificates.map(c => {
    const user = db.findUserById(c.userId);
    return { ...c, user: user ? { id: user.id, name: `${user.firstName} ${user.lastName}`, email: user.email } : null };
  });
  return success(res, certs);
});

// PUT verify certificate
router.put('/certificates/:id/verify', (req, res) => {
  const cert = db.certificates.find(c => c.id === req.params.id);
  if (!cert) return notFound(res, 'Certificate not found');
  cert.status = 'verified';
  cert.verifiedAt = new Date();
  cert.verifiedBy = req.user.id;
  db.updateUser(cert.userId, { meritCoins: (db.findUserById(cert.userId)?.meritCoins || 0) + 50 });
  db.addNotification(cert.userId, { type: 'success', icon: 'certificate', title: 'Certificate Verified!', message: `${cert.name} has been verified. +50 Merit Coins!` });
  return success(res, cert, 'Certificate verified');
});

// GET all jobs (admin)
router.get('/jobs', (req, res) => success(res, db.jobs));

// PUT update job status
router.put('/jobs/:id', (req, res) => {
  const job = db.jobs.find(j => j.id === req.params.id);
  if (!job) return notFound(res, 'Job not found');
  Object.assign(job, req.body);
  return success(res, job, 'Job updated');
});

module.exports = router;
