const router = require('express').Router();
const { body, validationResult } = require('express-validator');
const { v4: uuidv4 } = require('uuid');
const db = require('../config/database');
const { authenticate } = require('../middleware/auth');
const { success, created, notFound, badRequest } = require('../utils/response');

// GET portfolio overview
router.get('/', authenticate, (req, res) => {
  const user = req.user;
  const projects = db.projects.filter(p => p.userId === user.id);
  const certs = db.certificates.filter(c => c.userId === user.id);

  return success(res, {
    user: {
      id: user.id,
      name: `${user.firstName} ${user.lastName}`,
      title: user.title,
      bio: user.bio,
      location: user.location,
      avatar: user.avatar,
      skills: user.skills || [],
    },
    projects,
    certificates: certs,
    stats: {
      projectCount: projects.length,
      avgScore: projects.length ? (projects.reduce((s, p) => s + p.score, 0) / projects.length).toFixed(1) : 0,
      totalViews: projects.reduce((s, p) => s + p.views, 0),
      certCount: certs.length,
    },
  });
});

// GET projects
router.get('/projects', authenticate, (req, res) => {
  return success(res, db.projects.filter(p => p.userId === req.user.id));
});

// POST add project
router.post('/projects', authenticate, [
  body('title').trim().isLength({ min: 3, max: 100 }),
  body('description').isLength({ min: 10, max: 1000 }),
  body('technologies').isArray({ min: 1 }),
], (req, res) => {
  const errors = validationResult(req);
  if (!errors.isEmpty()) return badRequest(res, 'Validation failed', errors.array());

  const project = {
    id: `p-${uuidv4().slice(0, 8)}`,
    userId: req.user.id,
    ...req.body,
    score: (Math.random() * 2 + 7.5).toFixed(1),
    views: 0,
    thumbnail: `https://placehold.co/400x250/4f46e5/white?text=${encodeURIComponent(req.body.title.substring(0, 15))}`,
    createdAt: new Date(),
  };
  db.projects.push(project);
  db.updateUser(req.user.id, { meritCoins: (req.user.meritCoins || 0) + 25 });

  return created(res, project, 'Project added! +25 Merit Coins');
});

// PUT update project
router.put('/projects/:id', authenticate, (req, res) => {
  const idx = db.projects.findIndex(p => p.id === req.params.id && p.userId === req.user.id);
  if (idx === -1) return notFound(res, 'Project not found');
  db.projects[idx] = { ...db.projects[idx], ...req.body };
  return success(res, db.projects[idx], 'Project updated');
});

// DELETE project
router.delete('/projects/:id', authenticate, (req, res) => {
  const idx = db.projects.findIndex(p => p.id === req.params.id && p.userId === req.user.id);
  if (idx === -1) return notFound(res, 'Project not found');
  db.projects.splice(idx, 1);
  return success(res, null, 'Project deleted');
});

// PUT update skills
router.put('/skills', authenticate, (req, res) => {
  const { skills } = req.body;
  if (!Array.isArray(skills)) return badRequest(res, 'Skills must be an array');
  db.updateUser(req.user.id, { skills });
  return success(res, { skills }, 'Skills updated');
});

module.exports = router;
