const router = require('express').Router();
const db = require('../config/database');
const { authenticate } = require('../middleware/auth');
const { success } = require('../utils/response');

const defaultSettings = {
  notifications: { email: true, push: true, jobAlerts: true, courseUpdates: true, weeklyDigest: false },
  privacy: { profileVisible: true, showEmail: false, showLocation: true },
  preferences: { theme: 'light', language: 'en', timezone: 'Africa/Lagos' },
};

// In-memory settings store
const userSettings = {};

// GET settings
router.get('/', authenticate, (req, res) => {
  return success(res, userSettings[req.user.id] || defaultSettings);
});

// PUT update settings
router.put('/', authenticate, (req, res) => {
  userSettings[req.user.id] = { ...(userSettings[req.user.id] || defaultSettings), ...req.body };
  return success(res, userSettings[req.user.id], 'Settings saved');
});

// GET notification settings
router.get('/notifications', authenticate, (req, res) => {
  const settings = userSettings[req.user.id] || defaultSettings;
  return success(res, settings.notifications);
});

// PUT update notification settings
router.put('/notifications', authenticate, (req, res) => {
  if (!userSettings[req.user.id]) userSettings[req.user.id] = { ...defaultSettings };
  userSettings[req.user.id].notifications = { ...userSettings[req.user.id].notifications, ...req.body };
  return success(res, userSettings[req.user.id].notifications, 'Notification settings updated');
});

// GET privacy settings
router.get('/privacy', authenticate, (req, res) => {
  const settings = userSettings[req.user.id] || defaultSettings;
  return success(res, settings.privacy);
});

// PUT update privacy settings
router.put('/privacy', authenticate, (req, res) => {
  if (!userSettings[req.user.id]) userSettings[req.user.id] = { ...defaultSettings };
  userSettings[req.user.id].privacy = { ...userSettings[req.user.id].privacy, ...req.body };
  return success(res, userSettings[req.user.id].privacy, 'Privacy settings updated');
});

module.exports = router;
