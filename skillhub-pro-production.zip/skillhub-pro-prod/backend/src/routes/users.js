const router = require('express').Router();
const bcrypt = require('bcryptjs');
const { body, validationResult } = require('express-validator');
const db = require('../config/database');
const { authenticate, requireRole } = require('../middleware/auth');
const { success, badRequest, notFound } = require('../utils/response');
const { sanitizeUser } = require('../utils/jwt');

// GET current user profile
router.get('/me', authenticate, (req, res) => success(res, sanitizeUser(req.user)));

// PUT update profile
router.put('/me', authenticate, [
  body('firstName').optional().trim().isLength({ min: 2, max: 50 }),
  body('lastName').optional().trim().isLength({ min: 2, max: 50 }),
  body('title').optional().trim().isLength({ max: 100 }),
  body('bio').optional().isLength({ max: 500 }),
  body('location').optional().trim().isLength({ max: 100 }),
], (req, res) => {
  const errors = validationResult(req);
  if (!errors.isEmpty()) return badRequest(res, 'Validation failed', errors.array());

  const allowed = ['firstName', 'lastName', 'title', 'bio', 'location', 'company', 'website', 'github', 'linkedin'];
  const updates = {};
  allowed.forEach(k => { if (req.body[k] !== undefined) updates[k] = req.body[k]; });

  // Recalculate profile strength
  const user = { ...req.user, ...updates };
  let strength = 30;
  if (user.bio && user.bio.length > 20) strength += 15;
  if (user.location) strength += 10;
  if (user.title) strength += 10;
  if ((user.skills || []).length >= 3) strength += 15;
  if (user.github || user.linkedin) strength += 10;
  if (user.website) strength += 10;
  updates.profileStrength = Math.min(100, strength);

  const updated = db.updateUser(req.user.id, updates);
  return success(res, sanitizeUser(updated), 'Profile updated');
});

// PUT change password
router.put('/me/password', authenticate, [
  body('currentPassword').notEmpty(),
  body('newPassword').isLength({ min: 8 }).matches(/^(?=.*[A-Z])(?=.*[0-9])/),
], async (req, res) => {
  const errors = validationResult(req);
  if (!errors.isEmpty()) return badRequest(res, 'Validation failed', errors.array());

  const { currentPassword, newPassword } = req.body;
  const user = db.findUserById(req.user.id);

  const isMatch = await bcrypt.compare(currentPassword, user.password);
  if (!isMatch) return badRequest(res, 'Current password is incorrect');

  const hashed = await bcrypt.hash(newPassword, 12);
  db.updateUser(req.user.id, { password: hashed });

  return success(res, null, 'Password changed successfully');
});

// GET user by ID (public profile)
router.get('/:id', authenticate, (req, res) => {
  const user = db.findUserById(req.params.id);
  if (!user) return notFound(res, 'User not found');
  const { password, ...safe } = user;
  return success(res, safe);
});

// GET all users (admin only)
router.get('/', authenticate, requireRole('admin'), (req, res) => {
  const users = db.users.map(u => sanitizeUser(u));
  return success(res, { users, total: users.length });
});

module.exports = router;
