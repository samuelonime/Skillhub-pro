const router = require('express').Router();
const db = require('../config/database');
const { authenticate } = require('../middleware/auth');
const { success } = require('../utils/response');

// ===== DASHBOARD OVERVIEW =====
router.get('/', authenticate, (req, res) => {
  const user = req.user;
  const enrolledCourses = db.courses.filter(c => c.enrolledBy.includes(user.id));
  const activeCourses = enrolledCourses.filter(c => c.progress > 0 && c.progress < 100);
  const completedCourses = enrolledCourses.filter(c => c.progress === 100);
  const userCerts = db.certificates.filter(c => c.userId === user.id);
  const userApps = db.applications.filter(a => a.userId === user.id);
  const userNotifs = db.notifications.filter(n => n.userId === user.id);

  return success(res, {
    user: { id: user.id, name: `${user.firstName} ${user.lastName}`, avatar: user.avatar, role: user.role, title: user.title, meritCoins: user.meritCoins, profileStrength: user.profileStrength || 60 },
    stats: {
      coursesEnrolled: enrolledCourses.length,
      coursesCompleted: completedCourses.length,
      activeCourses: activeCourses.length,
      certificates: userCerts.length,
      jobApplications: userApps.length,
      meritCoins: user.meritCoins,
      portfolioScore: 8.5,
      profileStrength: user.profileStrength || 60,
    },
    recentActivity: [
      { type: 'course', message: 'Completed Module 8 in React Mastery', time: '2 hours ago', icon: 'book' },
      { type: 'certificate', message: 'React Developer Certificate verified', time: '1 day ago', icon: 'certificate' },
      { type: 'job', message: 'Applied to Frontend Developer at TechVision', time: '2 days ago', icon: 'briefcase' },
      { type: 'coins', message: 'Earned 50 Merit Coins for quiz completion', time: '3 days ago', icon: 'coins' },
    ],
    unreadNotifications: userNotifs.filter(n => !n.read).length,
  });
});

// ===== STATS ONLY =====
router.get('/stats', authenticate, (req, res) => {
  const user = req.user;
  const enrolledCourses = db.courses.filter(c => c.enrolledBy.includes(user.id));
  return success(res, {
    coursesEnrolled: enrolledCourses.length,
    certificates: db.certificates.filter(c => c.userId === user.id).length,
    jobApplications: db.applications.filter(a => a.userId === user.id).length,
    meritCoins: user.meritCoins,
    profileStrength: user.profileStrength || 60,
  });
});

// ===== ACTIVITY FEED =====
router.get('/activity', authenticate, (req, res) => {
  const limit = parseInt(req.query.limit) || 10;
  return success(res, [
    { type: 'course', message: 'Completed Module 8 in React Mastery', time: '2 hours ago', icon: 'book' },
    { type: 'certificate', message: 'React Developer Certificate verified', time: '1 day ago', icon: 'certificate' },
    { type: 'job', message: 'Applied to Frontend Developer at TechVision', time: '2 days ago', icon: 'briefcase' },
    { type: 'coins', message: 'Earned 50 Merit Coins for quiz completion', time: '3 days ago', icon: 'coins' },
    { type: 'course', message: 'Started Node.js & APIs course', time: '5 days ago', icon: 'book' },
  ].slice(0, limit));
});

// ===== NOTIFICATIONS =====
router.get('/notifications', authenticate, (req, res) => {
  const notifs = db.notifications.filter(n => n.userId === req.user.id);
  return success(res, notifs);
});

router.put('/notifications/:id/read', authenticate, (req, res) => {
  const n = db.notifications.find(n => n.id === req.params.id && n.userId === req.user.id);
  if (n) n.read = true;
  return success(res, null, 'Marked as read');
});

router.put('/notifications/read-all', authenticate, (req, res) => {
  db.markNotificationsRead(req.user.id);
  return success(res, null, 'All marked as read');
});

module.exports = router;
