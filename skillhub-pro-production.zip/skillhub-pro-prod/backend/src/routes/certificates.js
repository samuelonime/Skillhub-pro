const router = require('express').Router();
const { v4: uuidv4 } = require('uuid');
const db = require('../config/database');
const { authenticate } = require('../middleware/auth');
const { success, created, notFound, badRequest } = require('../utils/response');

// GET all certificates for user
router.get('/', authenticate, (req, res) => {
  return success(res, db.certificates.filter(c => c.userId === req.user.id));
});

// GET certificate by ID
router.get('/:id', authenticate, (req, res) => {
  const cert = db.certificates.find(c => c.id === req.params.id && c.userId === req.user.id);
  if (!cert) return notFound(res, 'Certificate not found');
  return success(res, cert);
});

// POST upload/add certificate
router.post('/', authenticate, (req, res) => {
  const { name, issuer, issueDate, expiryDate, credentialId, credentialUrl } = req.body;
  if (!name || !issuer) return badRequest(res, 'Name and issuer are required');

  const cert = {
    id: `cert-${uuidv4().slice(0, 8)}`,
    userId: req.user.id,
    name, issuer, credentialId: credentialId || `CERT-${Date.now()}`,
    credentialUrl: credentialUrl || null,
    issueDate: issueDate ? new Date(issueDate) : new Date(),
    expiryDate: expiryDate ? new Date(expiryDate) : null,
    status: 'pending',
    createdAt: new Date(),
  };
  db.certificates.push(cert);
  db.addNotification(req.user.id, { type: 'info', icon: 'certificate', title: 'Certificate Submitted', message: `${name} is pending verification` });

  return created(res, cert, 'Certificate submitted for verification');
});

// POST verify certificate (simulate)
router.post('/:id/verify', authenticate, (req, res) => {
  const cert = db.certificates.find(c => c.id === req.params.id && c.userId === req.user.id);
  if (!cert) return notFound(res, 'Certificate not found');

  cert.status = 'verified';
  cert.verifiedAt = new Date();
  db.updateUser(req.user.id, { meritCoins: (req.user.meritCoins || 0) + 50 });
  db.addNotification(req.user.id, { type: 'success', icon: 'certificate', title: 'Certificate Verified!', message: `${cert.name} has been verified. +50 Merit Coins!` });

  return success(res, cert, 'Certificate verified! +50 Merit Coins');
});

// DELETE certificate
router.delete('/:id', authenticate, (req, res) => {
  const idx = db.certificates.findIndex(c => c.id === req.params.id && c.userId === req.user.id);
  if (idx === -1) return notFound(res, 'Certificate not found');
  db.certificates.splice(idx, 1);
  return success(res, null, 'Certificate deleted');
});

module.exports = router;
