const router = require('express').Router();
const { body, validationResult } = require('express-validator');
const { v4: uuidv4 } = require('uuid');
const db = require('../config/database');
const { authenticate, requireRole } = require('../middleware/auth');
const { success, created, notFound, badRequest } = require('../utils/response');

// GET all jobs with filters
router.get('/', authenticate, (req, res) => {
  const { type, location, search, minMatch } = req.query;
  let jobs = db.jobs.filter(j => j.status === 'active');

  if (type) jobs = jobs.filter(j => j.type.toLowerCase() === type.toLowerCase());
  if (location) jobs = jobs.filter(j => j.location.toLowerCase().includes(location.toLowerCase()));
  if (search) jobs = jobs.filter(j => j.title.toLowerCase().includes(search.toLowerCase()) || j.company.toLowerCase().includes(search.toLowerCase()));

  const result = jobs.map(j => ({
    ...j,
    applied: j.applications.some(appId => db.applications.find(a => a.id === appId && a.userId === req.user.id)),
    saved: j.saved.includes(req.user.id),
    applicationCount: j.applications.length,
  }));

  return success(res, result);
});

// GET job matches for user
router.get('/matches', authenticate, (req, res) => {
  const userSkills = req.user.skills || [];
  const jobs = db.jobs.filter(j => j.status === 'active').map(j => ({
    ...j,
    match: Math.min(100, 40 + userSkills.filter(s => j.skills.some(js => js.toLowerCase().includes(s.toLowerCase()))).length * 20),
    applied: j.applications.some(appId => db.applications.find(a => a.id === appId && a.userId === req.user.id)),
    saved: j.saved.includes(req.user.id),
  })).filter(j => j.match >= 40).sort((a, b) => b.match - a.match);

  return success(res, jobs);
});

// GET saved jobs
router.get('/saved', authenticate, (req, res) => {
  const saved = db.jobs.filter(j => j.saved.includes(req.user.id)).map(j => ({ ...j, applied: false, saved: true }));
  return success(res, saved);
});

// GET user applications
router.get('/applications', authenticate, (req, res) => {
  const apps = db.applications.filter(a => a.userId === req.user.id).map(a => {
    const job = db.jobs.find(j => j.id === a.jobId);
    return { ...a, job };
  });
  return success(res, apps);
});

// GET single job
router.get('/:id', authenticate, (req, res) => {
  const job = db.jobs.find(j => j.id === req.params.id);
  if (!job) return notFound(res, 'Job not found');
  return success(res, { ...job, applied: job.applications.some(appId => db.applications.find(a => a.id === appId && a.userId === req.user.id)), saved: job.saved.includes(req.user.id) });
});

// POST apply to job
router.post('/:id/apply', authenticate, requireRole('student'), [
  body('coverLetter').optional().isString().isLength({ max: 2000 }),
], (req, res) => {
  const job = db.jobs.find(j => j.id === req.params.id);
  if (!job) return notFound(res, 'Job not found');

  const alreadyApplied = job.applications.some(appId => db.applications.find(a => a.id === appId && a.userId === req.user.id));
  if (alreadyApplied) return badRequest(res, 'Already applied to this job');

  const application = db.applyToJob(req.params.id, req.user.id, { coverLetter: req.body.coverLetter || '' });
  db.addNotification(req.user.id, { type: 'success', icon: 'briefcase', title: 'Application Submitted', message: `Applied to ${job.title} at ${job.company}` });

  return created(res, application, 'Application submitted successfully!');
});

// POST save/unsave job
router.post('/:id/save', authenticate, (req, res) => {
  const result = db.saveJob(req.params.id, req.user.id);
  if (!result) return notFound(res, 'Job not found');
  return success(res, result, result.saved ? 'Job saved' : 'Job removed from saved');
});

// POST create job (employer only)
router.post('/', authenticate, requireRole('employer', 'admin'), [
  body('title').trim().isLength({ min: 3, max: 100 }),
  body('description').isLength({ min: 20 }),
  body('skills').isArray({ min: 1 }),
  body('type').isIn(['Full-time', 'Part-time', 'Contract', 'Remote', 'Internship']),
], (req, res) => {
  const errors = validationResult(req);
  if (!errors.isEmpty()) return badRequest(res, 'Validation failed', errors.array());

  const job = {
    id: `j-${uuidv4().slice(0, 8)}`,
    ...req.body,
    company: req.user.company || `${req.user.firstName}'s Company`,
    applications: [],
    saved: [],
    status: 'active',
    posted: new Date(),
    match: 0,
  };
  db.jobs.push(job);

  return created(res, job, 'Job posted successfully!');
});

module.exports = router;
