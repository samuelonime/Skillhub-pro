const router = require('express').Router();
const bcrypt = require('bcryptjs');
const { body, validationResult } = require('express-validator');
const db = require('../config/database');
const { generateAccessToken, generateRefreshToken, verifyRefreshToken, sanitizeUser } = require('../utils/jwt');
const { success, created, badRequest, unauthorized, error } = require('../utils/response');
const { authenticate } = require('../middleware/auth');

// ===== REGISTER =====
// Admin accounts are pre-seeded — registration is for students, employers, and instructors only.
router.post('/register', [
  body('email').isEmail().normalizeEmail(),
  body('password').isLength({ min: 8 }).matches(/^(?=.*[A-Z])(?=.*[0-9])/),
  body('firstName').trim().isLength({ min: 2, max: 50 }),
  body('lastName').trim().isLength({ min: 2, max: 50 }),
  body('role').isIn(['student', 'employer', 'instructor']),
], async (req, res) => {
  const errors = validationResult(req);
  if (!errors.isEmpty()) return badRequest(res, 'Validation failed', errors.array());

  const { email, password, firstName, lastName, role, company } = req.body;

  if (db.findUserByEmail(email)) return badRequest(res, 'Email already registered');

  const hashedPassword = await bcrypt.hash(password, 12);
  const user = db.createUser({ email, password: hashedPassword, firstName, lastName, role, company: company || null,
    avatar: `https://ui-avatars.com/api/?name=${firstName}+${lastName}&background=4f46e5&color=fff&bold=true`,
    title: role === 'employer' ? 'Employer' : 'Learner', bio: '', location: '', skills: [],
  });

  const accessToken = generateAccessToken({ id: user.id, email: user.email, role: user.role });
  const refreshToken = generateRefreshToken({ id: user.id });
  db.storeRefreshToken(refreshToken);

  // Welcome notification
  db.addNotification(user.id, { type: 'success', icon: 'star', title: 'Welcome to SkillHub!', message: 'Your account has been created. Start exploring courses and opportunities.' });

  return created(res, { user: sanitizeUser(user), accessToken, refreshToken }, 'Account created successfully');
});

// ===== LOGIN =====
router.post('/login', [
  body('email').isEmail().normalizeEmail(),
  body('password').notEmpty(),
], async (req, res) => {
  const errors = validationResult(req);
  if (!errors.isEmpty()) return badRequest(res, 'Validation failed', errors.array());

  const { email, password } = req.body;
  const user = db.findUserByEmail(email);
  if (!user) return unauthorized(res, 'Invalid credentials');

  const isMatch = await bcrypt.compare(password, user.password);
  if (!isMatch) return unauthorized(res, 'Invalid credentials');

  const accessToken = generateAccessToken({ id: user.id, email: user.email, role: user.role });
  const refreshToken = generateRefreshToken({ id: user.id });
  db.storeRefreshToken(refreshToken);

  return success(res, { user: sanitizeUser(user), accessToken, refreshToken }, 'Login successful');
});

// ===== REFRESH TOKEN =====
router.post('/refresh', (req, res) => {
  const { refreshToken } = req.body;
  if (!refreshToken) return unauthorized(res, 'Refresh token required');
  if (!db.isRefreshTokenValid(refreshToken)) return unauthorized(res, 'Invalid refresh token');

  try {
    const decoded = verifyRefreshToken(refreshToken);
    const user = db.findUserById(decoded.id);
    if (!user) return unauthorized(res, 'User not found');

    db.revokeRefreshToken(refreshToken);
    const newAccessToken = generateAccessToken({ id: user.id, email: user.email, role: user.role });
    const newRefreshToken = generateRefreshToken({ id: user.id });
    db.storeRefreshToken(newRefreshToken);

    return success(res, { accessToken: newAccessToken, refreshToken: newRefreshToken }, 'Token refreshed');
  } catch {
    return unauthorized(res, 'Invalid refresh token');
  }
});

// ===== LOGOUT =====
router.post('/logout', authenticate, (req, res) => {
  const { refreshToken } = req.body;
  if (refreshToken) db.revokeRefreshToken(refreshToken);
  return success(res, null, 'Logged out successfully');
});

// ===== GET CURRENT USER =====
router.get('/me', authenticate, (req, res) => {
  return success(res, sanitizeUser(req.user));
});

module.exports = router;
