const router = require('express').Router();
const db = require('../config/database');
const { authenticate } = require('../middleware/auth');
const { success, notFound, badRequest } = require('../utils/response');

// GET all courses (with optional filters)
router.get('/', authenticate, (req, res) => {
  const { category, level, search } = req.query;
  let courses = db.getCoursesForUser(req.user.id);

  if (category) courses = courses.filter(c => c.category.toLowerCase() === category.toLowerCase());
  if (level) courses = courses.filter(c => c.level.toLowerCase() === level.toLowerCase());
  if (search) courses = courses.filter(c => c.title.toLowerCase().includes(search.toLowerCase()));

  return success(res, courses);
});

// GET recommended courses
router.get('/recommended', authenticate, (req, res) => {
  const courses = db.getCoursesForUser(req.user.id).filter(c => !c.enrolled).slice(0, 4);
  return success(res, courses);
});

// GET enrolled courses
router.get('/enrolled', authenticate, (req, res) => {
  const courses = db.getCoursesForUser(req.user.id).filter(c => c.enrolled);
  return success(res, courses);
});

// GET course by ID
router.get('/:id', authenticate, (req, res) => {
  const course = db.courses.find(c => c.id === req.params.id);
  if (!course) return notFound(res, 'Course not found');
  return success(res, { ...course, enrolled: course.enrolledBy.includes(req.user.id) });
});

// POST enroll in course
router.post('/:id/enroll', authenticate, (req, res) => {
  const course = db.courses.find(c => c.id === req.params.id);
  if (!course) return notFound(res, 'Course not found');
  if (course.enrolledBy.includes(req.user.id)) return badRequest(res, 'Already enrolled');

  db.enrollCourse(req.params.id, req.user.id);
  db.updateUser(req.user.id, { meritCoins: (req.user.meritCoins || 0) + 10 });
  db.addNotification(req.user.id, { type: 'info', icon: 'book', title: 'Course Enrolled', message: `You enrolled in ${course.title}` });

  return success(res, { course: { ...course, enrolled: true } }, `Enrolled in ${course.title}!`);
});

// PUT update course progress
router.put('/:id/progress', authenticate, (req, res) => {
  const { progress } = req.body;
  if (progress < 0 || progress > 100) return badRequest(res, 'Progress must be between 0 and 100');

  const course = db.courses.find(c => c.id === req.params.id);
  if (!course) return notFound(res, 'Course not found');

  course.progress = progress;

  if (progress === 100) {
    db.updateUser(req.user.id, { meritCoins: (req.user.meritCoins || 0) + 100 });
    db.addNotification(req.user.id, { type: 'success', icon: 'certificate', title: 'Course Completed!', message: `Congratulations! You completed ${course.title}. +100 Merit Coins!` });
  }

  return success(res, { progress }, 'Progress updated');
});

module.exports = router;
