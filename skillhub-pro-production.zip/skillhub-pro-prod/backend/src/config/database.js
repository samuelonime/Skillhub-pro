// SkillHub In-Memory Database (replace with MongoDB/PostgreSQL in production)
const { v4: uuidv4 } = require('uuid');
const bcrypt = require('bcryptjs');

// ===== SEED DATA =====
const seedUsers = async () => {
  const hash = (pw) => bcrypt.hashSync(pw, 10);
  return [
    {
      id: 'user-001',
      email: 'student@skillhub.com',
      password: hash('Password123!'),
      firstName: 'Alex',
      lastName: 'Johnson',
      role: 'student',
      avatar: 'https://ui-avatars.com/api/?name=Alex+Johnson&background=4f46e5&color=fff&bold=true',
      title: 'Full Stack Developer',
      bio: 'Passionate developer with 2 years of experience building web apps.',
      location: 'Lagos, Nigeria',
      profileStrength: 78,
      meritCoins: 1250,
      skills: ['JavaScript', 'React', 'Node.js', 'Python', 'CSS'],
      createdAt: new Date('2024-01-15'),
      verified: true,
    },
    {
      id: 'user-002',
      email: 'employer@skillhub.com',
      password: hash('Password123!'),
      firstName: 'Sarah',
      lastName: 'Williams',
      role: 'employer',
      avatar: 'https://ui-avatars.com/api/?name=Sarah+Williams&background=10b981&color=fff&bold=true',
      company: 'TechVision Africa',
      title: 'HR Manager',
      bio: 'Talent acquisition specialist focused on tech roles.',
      location: 'Abuja, Nigeria',
      meritCoins: 500,
      createdAt: new Date('2024-02-01'),
      verified: true,
    },
    {
      id: 'user-003',
      email: 'admin@skillhub.com',
      password: hash('Admin123!'),
      firstName: 'Admin',
      lastName: 'User',
      role: 'admin',
      avatar: 'https://ui-avatars.com/api/?name=Admin+User&background=ef4444&color=fff&bold=true',
      title: 'Platform Administrator',
      createdAt: new Date('2024-01-01'),
      verified: true,
    },
  ];
};

// ===== DATABASE SINGLETON =====
class Database {
  constructor() {
    this.users = [];
    this.courses = [];
    this.jobs = [];
    this.applications = [];
    this.certificates = [];
    this.projects = [];
    this.notifications = [];
    this.transactions = [];
    this.refreshTokens = new Set();
    this.initialized = false;
  }

  async init() {
    if (this.initialized) return;
    this.users = await seedUsers();
    this.courses = this._seedCourses();
    this.jobs = this._seedJobs();
    this.certificates = this._seedCertificates();
    this.projects = this._seedProjects();
    this.notifications = this._seedNotifications();
    this.initialized = true;
    console.log('✅ Database initialized with seed data');
  }

  _seedCourses() {
    return [
      { id: 'c-001', title: 'React Mastery', provider: 'Udemy', category: 'Frontend', level: 'Intermediate', duration: '40h', rating: 4.8, enrolled: 15420, price: 0, thumbnail: 'https://placehold.co/320x180/4f46e5/white?text=React', progress: 65, enrolledBy: ['user-001'] },
      { id: 'c-002', title: 'Node.js & APIs', provider: 'Coursera', category: 'Backend', level: 'Beginner', duration: '30h', rating: 4.7, enrolled: 9830, price: 0, thumbnail: 'https://placehold.co/320x180/10b981/white?text=Node.js', progress: 30, enrolledBy: ['user-001'] },
      { id: 'c-003', title: 'Python for Data Science', provider: 'edX', category: 'Data', level: 'Beginner', duration: '50h', rating: 4.9, enrolled: 23100, price: 0, thumbnail: 'https://placehold.co/320x180/f59e0b/white?text=Python', progress: 0, enrolledBy: [] },
      { id: 'c-004', title: 'AWS Cloud Fundamentals', provider: 'AWS', category: 'Cloud', level: 'Beginner', duration: '25h', rating: 4.6, enrolled: 11200, price: 0, thumbnail: 'https://placehold.co/320x180/ef4444/white?text=AWS', progress: 0, enrolledBy: [] },
      { id: 'c-005', title: 'UI/UX Design Principles', provider: 'Figma Academy', category: 'Design', level: 'Beginner', duration: '20h', rating: 4.7, enrolled: 7500, price: 0, thumbnail: 'https://placehold.co/320x180/8b5cf6/white?text=UI%2FUX', progress: 0, enrolledBy: [] },
      { id: 'c-006', title: 'TypeScript Deep Dive', provider: 'Frontend Masters', category: 'Frontend', level: 'Advanced', duration: '35h', rating: 4.9, enrolled: 5400, price: 0, thumbnail: 'https://placehold.co/320x180/06b6d4/white?text=TypeScript', progress: 0, enrolledBy: [] },
    ];
  }

  _seedJobs() {
    return [
      { id: 'j-001', title: 'Frontend Developer', company: 'TechVision Africa', location: 'Lagos', type: 'Full-time', salary: '₦400k–₦600k', skills: ['React', 'JavaScript', 'CSS'], match: 92, posted: new Date(Date.now() - 86400000), applications: [], saved: [], status: 'active', description: 'Build modern, responsive web applications for our growing SaaS platform.' },
      { id: 'j-002', title: 'Backend Engineer', company: 'Paystack', location: 'Remote', type: 'Full-time', salary: '$2,500–$4,000/mo', skills: ['Node.js', 'Python', 'PostgreSQL'], match: 78, posted: new Date(Date.now() - 172800000), applications: [], saved: [], status: 'active', description: 'Design and maintain scalable APIs powering Africa\'s leading payment platform.' },
      { id: 'j-003', title: 'Data Analyst', company: 'Andela', location: 'Remote', type: 'Contract', salary: '$1,800–$2,800/mo', skills: ['Python', 'SQL', 'Tableau'], match: 65, posted: new Date(Date.now() - 259200000), applications: [], saved: [], status: 'active', description: 'Transform raw data into actionable insights for engineering teams globally.' },
      { id: 'j-004', title: 'DevOps Engineer', company: 'Flutterwave', location: 'Lagos', type: 'Full-time', salary: '₦700k–₦1M', skills: ['AWS', 'Docker', 'CI/CD'], match: 55, posted: new Date(Date.now() - 345600000), applications: [], saved: [], status: 'active', description: 'Maintain cloud infrastructure supporting 10M+ transactions monthly.' },
      { id: 'j-005', title: 'UI/UX Designer', company: 'Interswitch', location: 'Lagos', type: 'Full-time', salary: '₦350k–₦500k', skills: ['Figma', 'Adobe XD', 'Research'], match: 50, posted: new Date(Date.now() - 432000000), applications: [], saved: [], status: 'active', description: 'Design delightful user experiences for fintech products used across Africa.' },
    ];
  }

  _seedCertificates() {
    return [
      { id: 'cert-001', userId: 'user-001', name: 'React Developer Certification', issuer: 'Meta', issueDate: new Date('2024-03-15'), expiryDate: new Date('2026-03-15'), status: 'verified', credentialId: 'META-REACT-2024-001' },
      { id: 'cert-002', userId: 'user-001', name: 'JavaScript Algorithms', issuer: 'freeCodeCamp', issueDate: new Date('2024-01-20'), expiryDate: null, status: 'verified', credentialId: 'FCC-JS-2024-555' },
      { id: 'cert-003', userId: 'user-001', name: 'AWS Cloud Practitioner', issuer: 'Amazon Web Services', issueDate: new Date('2023-11-10'), expiryDate: new Date('2026-11-10'), status: 'pending', credentialId: 'AWS-CP-2023-789' },
    ];
  }

  _seedProjects() {
    return [
      { id: 'p-001', userId: 'user-001', title: 'E-Commerce Platform', description: 'Full-stack e-commerce app with React, Node.js, and Stripe payments.', technologies: ['React', 'Node.js', 'MongoDB', 'Stripe'], liveUrl: '#', githubUrl: '#', thumbnail: 'https://placehold.co/400x250/4f46e5/white?text=Project+1', score: 9.2, views: 234, createdAt: new Date('2024-04-01') },
      { id: 'p-002', userId: 'user-001', title: 'Task Management App', description: 'Kanban-style project management tool with real-time collaboration.', technologies: ['React', 'Firebase', 'Tailwind'], liveUrl: '#', githubUrl: '#', thumbnail: 'https://placehold.co/400x250/10b981/white?text=Project+2', score: 8.7, views: 187, createdAt: new Date('2024-03-10') },
      { id: 'p-003', userId: 'user-001', title: 'Weather Dashboard', description: 'Real-time weather app using OpenWeather API with beautiful charts.', technologies: ['Vue.js', 'D3.js', 'API'], liveUrl: '#', githubUrl: '#', thumbnail: 'https://placehold.co/400x250/f59e0b/white?text=Project+3', score: 8.1, views: 143, createdAt: new Date('2024-02-20') },
    ];
  }

  _seedNotifications() {
    return [
      { id: 'n-001', userId: 'user-001', type: 'success', icon: 'certificate', title: 'Certificate Verified', message: 'React Developer Certification has been verified', read: false, createdAt: new Date(Date.now() - 7200000) },
      { id: 'n-002', userId: 'user-001', type: 'info', icon: 'briefcase', title: 'New Job Match', message: 'Frontend Developer at TechVision (92% match)', read: false, createdAt: new Date(Date.now() - 86400000) },
      { id: 'n-003', userId: 'user-001', type: 'warning', icon: 'calendar', title: 'Deadline Approaching', message: 'Project submission due in 3 days', read: true, createdAt: new Date(Date.now() - 172800000) },
    ];
  }

  // ===== USER HELPERS =====
  findUserByEmail(email) { return this.users.find(u => u.email === email.toLowerCase()); }
  findUserById(id) { return this.users.find(u => u.id === id); }
  createUser(data) {
    const user = { id: `user-${uuidv4().slice(0, 8)}`, ...data, createdAt: new Date(), meritCoins: 100, verified: false };
    this.users.push(user);
    return user;
  }
  updateUser(id, data) {
    const idx = this.users.findIndex(u => u.id === id);
    if (idx === -1) return null;
    this.users[idx] = { ...this.users[idx], ...data };
    return this.users[idx];
  }

  // ===== COURSE HELPERS =====
  getCoursesForUser(userId) {
    return this.courses.map(c => ({ ...c, enrolled: c.enrolledBy.includes(userId) }));
  }
  enrollCourse(courseId, userId) {
    const c = this.courses.find(c => c.id === courseId);
    if (c && !c.enrolledBy.includes(userId)) c.enrolledBy.push(userId);
    return c;
  }

  // ===== JOB HELPERS =====
  applyToJob(jobId, userId, data) {
    const app = { id: `app-${uuidv4().slice(0, 8)}`, jobId, userId, ...data, status: 'pending', appliedAt: new Date() };
    this.applications.push(app);
    const job = this.jobs.find(j => j.id === jobId);
    if (job) job.applications.push(app.id);
    return app;
  }
  saveJob(jobId, userId) {
    const job = this.jobs.find(j => j.id === jobId);
    if (!job) return null;
    const idx = job.saved.indexOf(userId);
    if (idx > -1) { job.saved.splice(idx, 1); return { saved: false }; }
    job.saved.push(userId);
    return { saved: true };
  }

  // ===== NOTIFICATION HELPERS =====
  addNotification(userId, data) {
    const n = { id: `n-${uuidv4().slice(0, 8)}`, userId, ...data, read: false, createdAt: new Date() };
    this.notifications.unshift(n);
    return n;
  }
  markNotificationsRead(userId) {
    this.notifications.filter(n => n.userId === userId).forEach(n => n.read = true);
  }

  // ===== TOKEN HELPERS =====
  storeRefreshToken(token) { this.refreshTokens.add(token); }
  revokeRefreshToken(token) { this.refreshTokens.delete(token); }
  isRefreshTokenValid(token) { return this.refreshTokens.has(token); }
}

const db = new Database();
module.exports = db;
