require('dotenv').config();
const express = require('express');
const cors = require('cors');
const helmet = require('helmet');
const compression = require('compression');
const morgan = require('morgan');
const rateLimit = require('express-rate-limit');
const crypto = require('crypto');
const path = require('path');
const db = require('./config/database');

// ===== ENV VALIDATION =====
const REQUIRED_ENV = ['JWT_SECRET', 'JWT_REFRESH_SECRET'];
const missing = REQUIRED_ENV.filter(k => !process.env[k] || process.env[k].startsWith('CHANGE_ME'));
if (missing.length) {
  console.error(`\n❌ Missing or placeholder environment variables: ${missing.join(', ')}`);
  console.error('   Copy backend/.env.example → backend/.env and set real values.\n');
  process.exit(1);
}

const IS_PROD = process.env.NODE_ENV === 'production';
const PORT = parseInt(process.env.PORT, 10) || 5000;
const app = express();

// ===== REQUEST ID =====
// Attach a unique ID to every request for log correlation
app.use((req, _res, next) => {
  req.id = crypto.randomUUID();
  next();
});

// ===== SECURITY HEADERS =====
app.use(helmet({
  crossOriginResourcePolicy: { policy: 'cross-origin' },
  contentSecurityPolicy: IS_PROD ? undefined : false, // only enforce CSP in production
}));

// ===== COMPRESSION =====
app.use(compression());

// ===== LOGGING =====
// In production use a concise format that omits sensitive headers; dev gets verbose.
const morganFormat = IS_PROD
  ? ':req[x-request-id] :method :url :status :res[content-length] - :response-time ms'
  : 'dev';
morgan.token('req', (req, _res, field) => (field === 'x-request-id' ? req.id : req[field]));
app.use(morgan(morganFormat));

// ===== CORS =====
const allowedOrigins = (process.env.FRONTEND_URL || '')
  .split(',')
  .map(s => s.trim())
  .filter(Boolean);

if (!IS_PROD && allowedOrigins.length === 0) {
  allowedOrigins.push('http://localhost:3000');
}

app.use(cors({
  origin: IS_PROD
    ? (origin, cb) => {
        // In production: reject requests from unknown origins
        if (!origin || allowedOrigins.includes(origin)) return cb(null, true);
        cb(new Error(`CORS: origin '${origin}' not allowed`));
      }
    : true, // dev: allow all origins
  methods: ['GET', 'POST', 'PUT', 'DELETE', 'OPTIONS'],
  allowedHeaders: ['Content-Type', 'Authorization'],
  credentials: true,
}));

// ===== BODY PARSING =====
app.use(express.json({ limit: '10mb' }));
app.use(express.urlencoded({ extended: true, limit: '10mb' }));

// ===== RATE LIMITING =====
const authLimiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  max: 20,
  standardHeaders: true,
  legacyHeaders: false,
  message: { success: false, message: 'Too many auth attempts. Please try again later.' },
});

const apiLimiter = rateLimit({
  windowMs: parseInt(process.env.RATE_LIMIT_WINDOW_MS, 10) || 15 * 60 * 1000,
  max: parseInt(process.env.RATE_LIMIT_MAX, 10) || 200,
  standardHeaders: true,
  legacyHeaders: false,
  message: { success: false, message: 'Too many requests. Please slow down.' },
});

app.use('/api/v1/auth', authLimiter);
app.use('/api', apiLimiter);

// ===== STATIC FILES =====
app.use('/uploads', express.static(path.join(__dirname, '../uploads')));

// ===== ROUTES =====
app.use('/api/v1/auth',         require('./routes/auth'));
app.use('/api/v1/dashboard',    require('./routes/dashboard'));
app.use('/api/v1/courses',      require('./routes/courses'));
app.use('/api/v1/jobs',         require('./routes/jobs'));
app.use('/api/v1/portfolio',    require('./routes/portfolio'));
app.use('/api/v1/certificates', require('./routes/certificates'));
app.use('/api/v1/users',        require('./routes/users'));
app.use('/api/v1/rewards',      require('./routes/rewards'));
app.use('/api/v1/settings',     require('./routes/settings'));
app.use('/api/v1/admin',        require('./routes/admin'));

// ===== HEALTH CHECK =====
app.get('/health', (_req, res) => res.json({
  status: 'healthy',
  version: '1.0.0',
  timestamp: new Date().toISOString(),
  uptime: Math.floor(process.uptime()),
}));

// ===== API INDEX =====
// NOTE: never expose test credentials or internal details in production
app.get('/api/v1', (_req, res) => res.json({
  name: 'SkillHub API',
  version: '1.0.0',
  docs: 'See README.md for full endpoint reference',
  endpoints: [
    '/api/v1/auth', '/api/v1/dashboard', '/api/v1/courses',
    '/api/v1/jobs', '/api/v1/portfolio', '/api/v1/certificates',
    '/api/v1/users', '/api/v1/rewards', '/api/v1/settings', '/api/v1/admin',
  ],
}));

// ===== 404 =====
app.use((req, res) =>
  res.status(404).json({ success: false, message: `Route ${req.method} ${req.path} not found` })
);

// ===== GLOBAL ERROR HANDLER =====
// eslint-disable-next-line no-unused-vars
app.use((err, req, res, _next) => {
  const status = err.status || err.statusCode || 500;
  console.error(`[${req.id}] Unhandled error (${status}):`, err.message);
  if (!IS_PROD) console.error(err.stack);

  res.status(status).json({
    success: false,
    message: IS_PROD && status === 500 ? 'Internal server error' : err.message,
    requestId: req.id,
  });
});

// ===== START =====
db.init().then(() => {
  const server = app.listen(PORT, () => {
    console.log(`\n🚀 SkillHub API running on http://localhost:${PORT}`);
    console.log(`📚 API index: http://localhost:${PORT}/api/v1`);
    console.log(`❤️  Health:   http://localhost:${PORT}/health`);
    if (!IS_PROD) console.log('\n⚠️  Running in development mode — use NODE_ENV=production for deployment\n');
  });

  // ===== GRACEFUL SHUTDOWN =====
  const shutdown = (signal) => {
    console.log(`\n${signal} received — shutting down gracefully…`);
    server.close(() => {
      console.log('HTTP server closed.');
      process.exit(0);
    });
    // Force-kill after 10 s if connections don't drain
    setTimeout(() => { console.error('Forcing exit.'); process.exit(1); }, 10_000);
  };
  process.on('SIGTERM', () => shutdown('SIGTERM'));
  process.on('SIGINT',  () => shutdown('SIGINT'));
}).catch(err => {
  console.error('Failed to initialise database:', err);
  process.exit(1);
});

module.exports = app;
