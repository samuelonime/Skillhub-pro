// layout.js — renders sidebar, topbar, notifications for all dashboard pages

function buildLayout({ page, role = 'student', title = 'SkillHub' }) {
  document.title = `${title} — SkillHub`;

  const user = SkillHub.getUser();
  if (!user) return;

  const navItems = {
    student: [
      { icon: 'fa-grid-2', label: 'Dashboard',    href: 'index.html',              id: 'dashboard' },
      { icon: 'fa-book-open', label: 'Courses',   href: 'courses.html',            id: 'courses' },
      { icon: 'fa-briefcase', label: 'Jobs',       href: 'jobs.html',               id: 'jobs' },
      { icon: 'fa-folder-open', label: 'Portfolio',href: 'portfolio.html',          id: 'portfolio' },
      { icon: 'fa-certificate', label: 'Certificates', href: 'certificates.html',   id: 'certificates' },
      { icon: 'fa-coins', label: 'Rewards',        href: 'rewards.html',            id: 'rewards' },
    ],
    employer: [
      { icon: 'fa-grid-2', label: 'Dashboard',    href: 'employer-dashboard.html', id: 'dashboard' },
      { icon: 'fa-briefcase', label: 'Jobs',       href: 'jobs.html',               id: 'jobs' },
      { icon: 'fa-users', label: 'Candidates',     href: 'candidates.html',         id: 'candidates' },
    ],
    admin: [
      { icon: 'fa-grid-2', label: 'Dashboard',    href: 'Admin.html',              id: 'dashboard' },
      { icon: 'fa-users', label: 'Users',          href: 'Admin.html#users',        id: 'users' },
      { icon: 'fa-briefcase', label: 'Jobs',       href: 'Admin.html#jobs',         id: 'jobs' },
      { icon: 'fa-certificate', label: 'Certificates', href: 'Admin.html#certs',    id: 'certificates' },
    ],
  };

  const nav = (navItems[user.role] || navItems.student).map(item => `
    <a class="nav-link ${page === item.id ? 'active' : ''}" href="${item.href}">
      <i class="fas ${item.icon}"></i>${item.label}
    </a>`).join('');

  document.querySelector('.sidebar-nav').innerHTML = `
    <span class="nav-label">Main</span>
    ${nav}
    <span class="nav-label" style="margin-top:12px">Account</span>
    <a class="nav-link ${page === 'settings' ? 'active' : ''}" href="settings.html"><i class="fas fa-gear"></i>Settings</a>
  `;

  document.querySelector('.sidebar-user-name').textContent = `${user.firstName} ${user.lastName}`;
  document.querySelector('.sidebar-user-role').textContent = user.role;
  const sideImg = document.querySelector('.sidebar-user img');
  if (sideImg) sideImg.src = user.avatar;

  const topImg = document.getElementById('topbarAvatar');
  if (topImg) topImg.src = user.avatar;

  const topTitle = document.getElementById('topbarTitle');
  if (topTitle) topTitle.textContent = title;

  // Load notifications
  loadNotifications();

  // Dropdown close on outside click
  document.addEventListener('click', e => {
    document.querySelectorAll('.dropdown-menu.open, .notif-panel.open').forEach(el => {
      if (!el.closest('.dropdown, .notif-wrap')?.contains(e.target)) el.classList.remove('open');
    });
  });
}

function toggleDropdown(id) {
  const m = document.getElementById(id);
  const wasOpen = m.classList.contains('open');
  document.querySelectorAll('.dropdown-menu.open, .notif-panel.open').forEach(el => el.classList.remove('open'));
  if (!wasOpen) m.classList.add('open');
}

async function loadNotifications() {
  try {
    const d = await SkillHub.notifications();
    if (!d?.success) return;
    const notifs = d.data;
    const unread = notifs.filter(n => !n.read).length;

    const dot = document.getElementById('notifDot');
    if (dot) dot.style.display = unread > 0 ? 'block' : 'none';

    const list = document.getElementById('notifList');
    if (!list) return;

    const iconMap = { certificate:'fa-certificate', briefcase:'fa-briefcase', book:'fa-book', coins:'fa-coins', star:'fa-star', calendar:'fa-calendar', gift:'fa-gift', info:'fa-info-circle' };

    list.innerHTML = notifs.length ? notifs.slice(0,8).map(n => `
      <div class="notif-item ${n.read ? '' : 'unread'}" onclick="markRead('${n.id}', this)">
        <div class="notif-icon ${n.type}"><i class="fas ${iconMap[n.icon] || 'fa-bell'}"></i></div>
        <div style="flex:1;min-width:0">
          <div class="notif-title">${n.title}</div>
          <div class="notif-msg">${n.message}</div>
        </div>
        <div class="notif-time">${relTime(n.createdAt)}</div>
      </div>`).join('') :
      '<div style="padding:24px;text-align:center;color:var(--muted);font-size:13px"><i class="fas fa-bell-slash" style="font-size:24px;margin-bottom:8px;display:block"></i>No notifications</div>';
  } catch {}
}

async function markRead(id, el) {
  el.classList.remove('unread');
  await SkillHub.markRead(id);
}

async function markAllRead() {
  document.querySelectorAll('.notif-item.unread').forEach(el => el.classList.remove('unread'));
  document.getElementById('notifDot').style.display = 'none';
  await SkillHub.markAllRead();
}
